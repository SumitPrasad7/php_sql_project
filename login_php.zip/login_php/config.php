<?php
$DB_SERVER="localhost";
$DB_Username="root";
$DB_Password="";
$DB_Name="user";
//establishing the connection
$db=mysqli_connect($DB_SERVER,$DB_Username,$DB_Password,$DB_Name);
//checking connection
?>